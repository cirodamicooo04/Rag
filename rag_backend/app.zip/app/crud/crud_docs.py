from app.db.models import Chunk, Conversation

from app.db.models import Document


def get_documents_by_status(db, status):
    return  db.query(Document).filter(Document.status == status).all()

def get_all_documents(db):
    return db.query(Document).all()

def update_document_text(db, file_hash, extracted_text, new_status):
    db.query(Document).filter(Document.file_hash == file_hash).update({"text": extracted_text, "status": new_status})
    db.commit()

def get_document_by_hash(db, file_hash):
    return db.query(Document).filter(Document.file_hash == file_hash).first()

def create_document(db, file_hash, file_name, file_path, file_type):
    document = Document(file_hash=file_hash, file_name=file_name, file_path=file_path, file_type=file_type)
    db.add(document)
    db.commit()
    db.refresh(document)
    return document


def create_chunk(db, chunk_id, doc_hash, text, index, title, scope, category, source_url, scraping_date):
    chunk = Chunk(chunk_id=chunk_id,document_hash=doc_hash,text=text,chunk_index=index, title=title, scope=scope, category=category, source_url=source_url, scraping_date=scraping_date)
    db.add(chunk)
    db.commit()
    db.refresh(chunk)
    return chunk

def update_document_status(db, file_hash, new_status):
    db.query(Document).filter(Document.file_hash == file_hash).update({"status": new_status})
    db.commit()

def get_unindexed_chunks(db):
    return db.query(Chunk).filter(Chunk.indexed == False).filter(Chunk.security_status == "PENDING").all()

def mark_chunk_as_indexed(db, chunk):
    db.query(Chunk).filter(Chunk.chunk_id == chunk.chunk_id).update({"indexed": True})
    db.query(Document).filter(Document.file_hash == chunk.document_hash).update({"status": "INDEXED"})
    db.query(Chunk).filter(Chunk.chunk_id == chunk.chunk_id).update({"security_status": "SAFE"})
    db.commit()

def save_conversation(db, user_query, response):
    new_conv = Conversation(question=user_query, answer=response)
    db.add(new_conv)
    db.commit()
    db.refresh(new_conv)
    return new_conv

def get_all_conversations(db):
    return db.query(Conversation).all()

def get_conversation(id, db):
    return db.query(Conversation).filter(Conversation.id == id).first()


def delete_conversation(id, db):
    db.query(Conversation).filter(Conversation.id == id).delete()
    db.commit()

def delete_dataset(db):
    db.query(Document).delete()
    db.query(Chunk).delete()
    db.commit()


def mark_chunk_as_quarantined(db, chunk, reason):
    db.query(Chunk).filter(Chunk.chunk_id == chunk.chunk_id).update({"security_status": "QUARANTINED"})
    db.query(Chunk).filter(Chunk.chunk_id == chunk.chunk_id).update({"security_reason": reason})
    db.commit()

def update_document_index_status(db, document_hash):
    chunks = (db.query(Chunk).filter(Chunk.document_hash == document_hash).all())

    document = (db.query(Document).filter(Document.file_hash == document_hash).first())

    if not document:
        return None

    if not chunks:
        document.status = "CHUNKED"
        db.commit()
        db.refresh(document)
        return document

    indexed_count = sum(1 for c in chunks if c.indexed)
    quarantined_count = sum(1 for c in chunks if c.security_status == "QUARANTINED")

    if indexed_count == len(chunks):
        document.status = "INDEXED"

    elif indexed_count > 0 and (quarantined_count > 0):
        document.status = "PARTIALLY_INDEXED"

    elif indexed_count == 0 and (quarantined_count > 0):
        document.status = "REJECTED_SECURITY"

    else:
        document.status = "CHUNKED"

    db.commit()
    db.refresh(document)

    return document